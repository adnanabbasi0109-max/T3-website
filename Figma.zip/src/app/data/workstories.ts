export interface Workstory {
  slug: string;
  title: string;
  summary: string;
  year: string;
  location: string;
  featured: boolean;
  domains: string[];
  industries: string[];
  services: string[];
  challenge?: string;
  intervention?: string;
  execution?: string[];
  outcome?: string;
  proofPoints?: string[];
  videoUrl?: string;
  image?: string;
}

export const workstories: Workstory[] = [
  {
    slug: 'share-a-coke',
    title: 'Share a Coke Campaign',
    summary: 'We brought the iconic "Share a Coke" campaign to life by merging OOH and Digital Media in a way that connected people like never before.',
    year: '2015',
    location: 'India',
    featured: true,
    domains: ['PR & Media Strategy', 'Social Media', 'Business Innovations'],
    industries: ['FMCG', 'Beverages'],
    services: ['Campaign Strategy', 'Experiential Marketing', 'Social Media', 'Content Creation', 'Media Relations'],
    challenge: 'Create a breakthrough campaign that reverses declining soft drink consumption among millennials and makes Coca-Cola personally relevant again.',
    intervention: 'A massive Coca-Cola bottle with LED screens displayed the names of loved ones, inviting consumers to share a Coke. This larger-than-life installation sparked personal connections and went viral, generating massive buzz across social media.',
    execution: [
      'Created massive LED-enabled Coca-Cola bottle installation',
      'Integrated digital technology for real-time name display',
      'Developed OOH campaign that encouraged personal sharing',
      'Created social media amplification strategy',
      'Generated viral content through consumer participation',
      'Merged traditional and digital touchpoints seamlessly'
    ],
    outcome: 'This larger-than-life installation sparked personal connections and went viral, generating massive buzz across social media.',
    proofPoints: [
      'Generated massive social media buzz',
      'Created viral moment for brand',
      'Strong consumer engagement and participation',
      'Successful integration of OOH and digital media'
    ],
    image: 'figma:asset/19ce915ca14a3a1e9caeded3e9ed18c46b8e3924.png'
  },
  {
    slug: 'twitter-asia-pacific',
    title: 'Creative Consulting for Twitter Asia Pacific',
    summary: 'We have partnered with Twitter Asia Pacific\'s Business Team, offering creative consulting and crafting winning strategies.',
    year: '2020-2022',
    location: 'Asia Pacific',
    featured: true,
    domains: ['Business Innovations', 'Social Media', 'Marketing'],
    industries: ['Technology', 'Social Media'],
    services: ['Creative Consulting', 'Pitch Strategy', 'Campaign Development', 'Client Relations'],
    challenge: 'Help Twitter Asia Pacific\'s business team win major brand partnerships and campaigns in a competitive social media landscape.',
    intervention: 'Our pitch presentations were taken to global brands, driving high-value ad campaigns on the platform. Our role was instrumental in helping Twitter secure big-ticket ad deals by empowering their business team with impactful solutions.',
    execution: [
      'Developed creative consulting framework for Twitter business team',
      'Crafted winning pitch presentations for global brands',
      'Created campaign strategies tailored to platform strengths',
      'Provided strategic guidance for major brand partnerships',
      'Designed high-impact creative solutions for advertisers'
    ],
    outcome: 'Our role was instrumental in helping Twitter secure big-ticket ad deals by empowering their business team with impactful solutions.',
    proofPoints: [
      'Secured major brand partnerships for Twitter',
      'Developed winning pitch strategies for global brands',
      'Contributed to high-value advertising campaigns',
      'Established long-term consulting partnership'
    ],
    image: 'figma:asset/1f809eb02c4f5d76ab6a06ca67ed04a5474dd731.png'
  },
  {
    slug: 'pinkwalk',
    title: 'PinkWalk — Rajasthan\'s Largest Mall',
    summary: 'From the very start, we shaped PinkWalk, Rajasthan\'s largest mall, spanning 11 lakh square feet.',
    year: '2022-2023',
    location: 'Jaipur',
    featured: true,
    domains: ['Brand Building', 'Marketing', 'Social Media'],
    industries: ['Real Estate', 'Retail'],
    services: ['Brand Naming', 'Identity Creation', 'Marketing Campaign', 'Strategic Communications'],
    challenge: 'Launch Rajasthan\'s largest mall with a brand that would resonate with the target audience and establish it as the premier retail destination.',
    intervention: 'Our journey began with brand naming and identity creation, followed by a strategic marketing campaign aimed at the right target audience. The result? PinkWalk became Jaipur\'s biggest buzzword, with India\'s most premier brands already onboarded, setting it up as the go-to destination for retail and entertainment in the region.',
    execution: [
      'Developed brand name "PinkWalk" with local cultural relevance',
      'Created comprehensive brand identity system',
      'Designed strategic marketing campaign for launch',
      'Targeted premium audience segments',
      'Secured partnerships with India\'s premier brands',
      'Built pre-launch and launch buzz across channels'
    ],
    outcome: 'PinkWalk became Jaipur\'s biggest buzzword, with India\'s most premier brands already onboarded, setting it up as the go-to destination for retail and entertainment in the region.',
    proofPoints: [
      'Became Jaipur\'s biggest retail buzzword',
      'Onboarded India\'s most premier brands',
      'Successfully launched 11 lakh sq ft mall',
      'Established as go-to destination for retail and entertainment'
    ],
    image: 'figma:asset/4ae0e32603f4f6d098125ea59890e876fae7bffd.png'
  },
  {
    slug: '14-woodland-park',
    title: '14 Woodland Park — High-End Residential Project',
    summary: 'For Manglam Group\'s 14 Woodland Park, we executed a comprehensive 360-degree campaign, from brand identity to full-scale marketing.',
    year: '2021-2022',
    location: 'Jaipur',
    featured: true,
    domains: ['Brand Building', 'Marketing'],
    industries: ['Real Estate'],
    services: ['360 Campaign', 'Brand Identity', 'Full-Scale Marketing', 'Strategic Communications'],
    challenge: 'Launch and sell a prestigious high-end residential project in Jaipur\'s competitive luxury real estate market.',
    intervention: 'This prestigious residential project at Shiprapath, Jaipur, was elevated through strategic communication that resonated with premium buyers. Today, 14 Woodland Park is nearly sold out, marking it as one of the most successful high-end residential projects in Jaipur.',
    execution: [
      'Developed comprehensive brand identity from ground up',
      'Created 360-degree campaign strategy',
      'Designed premium marketing collateral',
      'Implemented strategic communication targeting premium buyers',
      'Executed full-scale integrated marketing campaign',
      'Created compelling project visualization and storytelling'
    ],
    outcome: 'Today, 14 Woodland Park is nearly sold out, marking it as one of the most successful high-end residential projects in Jaipur.',
    proofPoints: [
      'Nearly sold out status achieved',
      'One of Jaipur\'s most successful high-end residential projects',
      'Strong resonance with premium buyer segment',
      'Successful 360-degree campaign execution'
    ],
    image: 'figma:asset/cf170e17733c0229d31b662996c7a4f11df595b5.png'
  },
  {
    slug: 'platina-ajinkya-rahane',
    title: 'The Ajinkya Rahane Factor at Platina',
    summary: 'We elevated the Anukampa Platina Terraces brand by bringing Indian cricketer Ajinkya Rahane on board as the brand ambassador.',
    year: '2022',
    location: 'Bhopal',
    featured: true,
    domains: ['Brand Building', 'Marketing', 'PR & Media Strategy'],
    industries: ['Real Estate'],
    services: ['Celebrity Endorsement', 'Documentary Production', 'Multi-Channel Campaign', 'Strategic Communications'],
    challenge: 'Differentiate Anukampa Platina Terraces in a competitive real estate market and create deep connections with buyers.',
    intervention: 'The 360-degree campaign included a compelling project documentary featuring buyers, architects, and stakeholders, each sharing their experiences and insights. This multifaceted approach highlighted the project\'s appeal and created a deep connection with both current and potential buyers, establishing Anukampa Platina Terraces as a premium residential destination.',
    execution: [
      'Brought Indian cricketer Ajinkya Rahane as brand ambassador',
      'Produced compelling project documentary',
      'Featured buyers, architects, and stakeholders sharing experiences',
      'Created 360-degree multi-channel campaign',
      'Developed strategic communication targeting premium segment',
      'Established emotional connection with buyer audience'
    ],
    outcome: 'This multifaceted approach highlighted the project\'s appeal and created a deep connection with both current and potential buyers, establishing Anukampa Platina Terraces as a premium residential destination.',
    proofPoints: [
      'Successfully positioned as premium residential destination',
      'Strong emotional connection with buyers',
      'Compelling documentary content showcasing real experiences',
      'Elevated brand through celebrity association'
    ],
    videoUrl: 'https://example.com/platina',
    image: 'figma:asset/ed604ffa0e025fbe5c91d7252272042fa8b1ca39.png'
  },
  {
    slug: 'desert-springs',
    title: 'Desert Springs Resort — Jashn in Jaisalmer',
    summary: 'We built the Desert Springs Resort brand in the heart of Jaisalmer\'s deserts with the theme \'Jashn in Jaisalmer,\' celebrating the rich cultural and traditional beauty of Rajasthan.',
    year: '2020-2021',
    location: 'Jaisalmer',
    featured: true,
    domains: ['Brand Building', 'Marketing'],
    industries: ['Hospitality'],
    services: ['Brand Development', 'Event Curation', 'Integrated Campaigns', 'Cultural Marketing'],
    challenge: 'Launch a new resort in Jaisalmer\'s competitive desert tourism landscape with differentiated positioning that celebrates local culture.',
    intervention: 'From event curation to integrated campaigns, we showcased the essence of Rajasthani heritage in every touchpoint of communication. This blend of luxury and authenticity positioned Desert Springs Resort as a premier destination for those seeking an immersive and culturally rich experience in the Thar Desert.',
    execution: [
      'Developed "Jashn in Jaisalmer" brand theme',
      'Created brand identity celebrating Rajasthani heritage',
      'Curated cultural events and experiences',
      'Designed integrated marketing campaigns',
      'Showcased luxury blended with authentic cultural elements',
      'Positioned resort as immersive cultural destination'
    ],
    outcome: 'This blend of luxury and authenticity positioned Desert Springs Resort as a premier destination for those seeking an immersive and culturally rich experience in the Thar Desert.',
    proofPoints: [
      'Positioned as premier cultural destination',
      'Successfully launched in competitive market',
      'Strong blend of luxury and authentic experience',
      'Differentiated through cultural celebration theme'
    ],
    videoUrl: 'https://example.com/desert-springs',
    image: 'figma:asset/9d47a8c89e5a843e84fae2af2828629c74437be6.png'
  },
  {
    slug: 'pepsico-katrina',
    title: 'PepsiCo Conference — Holographic Projection of Katrina Kaif',
    summary: 'In Pattaya, Thailand, we brought PepsiCo\'s vision to life with a stunning holographic projection of Katrina Kaif, the brand ambassador for Slice.',
    year: '2019',
    location: 'Pattaya, Thailand',
    featured: true,
    domains: ['Business Innovations', 'AI & Tech Solutions'],
    industries: ['Events', 'FMCG'],
    services: ['Experience Innovation', 'Technology Integration', 'Event Production', 'Holographic Technology'],
    challenge: 'Create an unforgettable moment at the PepsiCo conference that would captivate the audience and showcase brand innovation.',
    intervention: 'The near-real hologram had Katrina addressing the audience at the PepsiCo conference, creating an unforgettable experience. Our team flew in from Bhopal, executing the event with precision and finesse. The conference was followed by an outdoor campaign on the same theme, which we ideated to enhance brand visibility.',
    execution: [
      'Deployed cutting-edge holographic projection technology',
      'Created near-real hologram of Katrina Kaif',
      'Coordinated international event execution from Bhopal',
      'Managed technical precision and event flow',
      'Developed outdoor campaign extending the theme',
      'Integrated physical event with broader campaign strategy'
    ],
    outcome: 'The conference was followed by an outdoor campaign on the same theme, which we ideated to enhance brand visibility.',
    proofPoints: [
      'Created unforgettable holographic experience',
      'Successfully executed international event',
      'Extended campaign beyond event with outdoor activation',
      'Showcased technological innovation capability'
    ],
    image: 'figma:asset/6e1cc6e4ab881290007add52cdbf5f58a15ef59c.png'
  },
  {
    slug: 'friends-of-bhopal',
    title: 'Friends of Bhopal Property Fair',
    summary: 'For CREDAI Bhopal, we crafted an immersive property fair themed \'Friends of Bhopal.\'',
    year: '2023',
    location: 'Bhopal',
    featured: true,
    domains: ['Business Innovations', 'Art & Design'],
    industries: ['Events', 'Real Estate'],
    services: ['Experience Design', 'Event Strategy', 'Content Creation', 'Community Engagement'],
    challenge: 'Create a differentiated property fair that goes beyond conventional real estate exhibitions and celebrates the city.',
    intervention: 'The event spotlighted innovation with a grand selfie station, while a surprise public painting slowly revealed a stunning portrait of Bhopal, created by its own citizens. A captivating photo gallery shared the rich history and development of Bhopal, engaging visitors with intriguing facts. This unique blend of creativity and community spirit made the event an unforgettable experience for all.',
    execution: [
      'Developed "Friends of Bhopal" event theme',
      'Created grand selfie station for visitor engagement',
      'Designed surprise public painting activity revealing Bhopal portrait',
      'Curated photo gallery showcasing Bhopal\'s history and development',
      'Engaged citizens in collaborative art creation',
      'Blended creativity with community participation'
    ],
    outcome: 'This unique blend of creativity and community spirit made the event an unforgettable experience for all.',
    proofPoints: [
      'Created unforgettable community-driven experience',
      'High visitor engagement through interactive installations',
      'Celebrated city identity and heritage',
      'Set new standard for property exhibitions'
    ],
    videoUrl: 'https://example.com/friends-of-bhopal',
    image: 'figma:asset/912a9109ca0483d582b8547a4ea85c4a30aab57b.png'
  },
  {
    slug: 'kamaal-ka-bhopal',
    title: 'Kamaal Ka Bhopal — Global Investor Summit 2025',
    summary: 'We put Bhopal in the spotlight with the Kamaal Ka Bhopal campaign at the Global Investor Summit 2025.',
    year: '2025',
    location: 'Bhopal',
    featured: true,
    domains: ['Brand Building', 'PR & Media Strategy', 'Social Media'],
    industries: ['Political Communication', 'Events'],
    services: ['Campaign Strategy', 'Content Creation', 'Media Relations', 'Social Media Management'],
    challenge: 'Position Bhopal as a rising investment and cultural hub at a global summit with national and international attention.',
    intervention: 'Through a powerful mix of an eye-catching OOH campaign, an immersive grand photo booth, a compelling documentary on Bhopal\'s growth story, and a high-impact social media outreach, we captured hearts and attention alike. The campaign sparked unprecedented engagement and was extensively covered by premier media channels, solidifying Bhopal\'s position as a rising investment and cultural hub.',
    execution: [
      'Created "Kamaal Ka Bhopal" campaign identity',
      'Developed eye-catching OOH campaign',
      'Designed immersive grand photo booth experience',
      'Produced compelling documentary on Bhopal\'s growth story',
      'Executed high-impact social media outreach',
      'Generated extensive media coverage in premier channels'
    ],
    outcome: 'The campaign sparked unprecedented engagement and was extensively covered by premier media channels, solidifying Bhopal\'s position as a rising investment and cultural hub.',
    proofPoints: [
      'Unprecedented engagement achieved',
      'Extensive coverage by premier media channels',
      'Positioned Bhopal as investment and cultural hub',
      'Strong national and international attention',
      'Successful integration of multiple touchpoints'
    ],
    videoUrl: 'https://example.com/kamaal-ka-bhopal',
    image: 'figma:asset/11f331f46019762724312db59a14cc1884e05355.png'
  },
  {
    slug: 'giovanni-village',
    title: 'Giovanni Village Luxury Resort',
    summary: 'From concept to reality, we shaped the Giovanni Village brand, a luxury resort in Bhopal.',
    year: '2023',
    location: 'Bhopal',
    featured: true,
    domains: ['Brand Building', 'Art & Design', 'Social Media'],
    industries: ['Hospitality'],
    services: ['Brand Identity', 'Website Development', 'Social Media Marketing', 'Process Automation'],
    challenge: 'Launch a new luxury resort with complete brand ecosystem covering every touchpoint from identity to operations.',
    intervention: 'Our involvement spanned every detail—logo design, site signage, and guest experience aesthetics, all crafted to exude elegance. We designed a seamless website, amplified the brand through social media marketing, and streamlined operations with process automation. Giovanni Village became a benchmark for luxury hospitality, thanks to a cohesive brand identity and a memorable guest experience.',
    execution: [
      'Developed comprehensive brand identity (logo, signage, aesthetics)',
      'Designed guest experience touchpoints for luxury feel',
      'Built seamless website with booking integration',
      'Created social media marketing strategy',
      'Implemented process automation for operations',
      'Crafted cohesive brand system across all touchpoints'
    ],
    outcome: 'Giovanni Village became a benchmark for luxury hospitality, thanks to a cohesive brand identity and a memorable guest experience.',
    proofPoints: [
      'Became benchmark for luxury hospitality',
      'Cohesive brand experience across all touchpoints',
      'Successfully launched with strong market positioning',
      'Streamlined operations through automation'
    ],
    videoUrl: 'https://example.com/giovanni',
    image: 'figma:asset/bd04fa864800b474eb0fc2b7bb95659b671d6d25.png'
  },
  {
    slug: 'manglam-aananda',
    title: 'Manglam Aananda',
    summary: 'A documentary-style campaign that brought a residential project to life, resulting in complete sellout.',
    year: '2023',
    location: 'Jaipur',
    featured: false,
    domains: ['Brand Building', 'Marketing', 'Art & Design'],
    industries: ['Real Estate'],
    services: ['Documentary Production', 'Campaign Strategy', 'Content Marketing', 'Brand Storytelling'],
    challenge: 'Differentiate a luxury residential project in Jaipur\'s premium real estate segment.',
    intervention: 'Created documentary-style content that told the story of the project, focusing on lifestyle narrative rather than just property features.',
    execution: [
      'Produced documentary content showcasing project vision',
      'Developed lifestyle-focused brand narrative',
      'Created integrated campaign across channels',
      'Designed sales materials with storytelling approach'
    ],
    outcome: 'Completely sold out',
    proofPoints: [
      'Project completely sold out',
      'Strong emotional connection with buyers',
      'Documentary content generated significant engagement'
    ]
  },
  {
    slug: 'polywood-rebrand',
    title: 'Polywood Rebranding',
    summary: 'Shifting perception of a manufacturing brand from commodity to premium product category.',
    year: '2023',
    location: 'India',
    featured: false,
    domains: ['Brand Building', 'Business Innovations'],
    industries: ['Manufacturing'],
    services: ['Brand Repositioning', 'Identity Design', 'Marketing Strategy', 'Perception Management'],
    challenge: 'Transform perception of Polywood from generic manufacturing brand to premium building material choice.',
    intervention: 'Complete brand overhaul focusing on product quality, innovation, and sustainable practices.',
    execution: [
      'Redesigned brand identity with premium positioning',
      'Created new visual language and messaging framework',
      'Developed marketing materials emphasizing quality and innovation',
      'Implemented perception shift campaign targeting architects and builders'
    ],
    outcome: 'Successfully repositioned brand in premium segment.',
    proofPoints: [
      'Perception shift from commodity to premium brand',
      'Increased engagement with architect and designer community',
      'Stronger pricing power and brand equity',
      'Differentiated positioning in competitive market'
    ]
  }
];

export const getFeaturedWorkstories = () => workstories.filter(w => w.featured);

export const getWorkstoryBySlug = (slug: string) => workstories.find(w => w.slug === slug);

export const filterWorkstories = (filters: {
  search?: string;
  domain?: string;
  industry?: string;
  featured?: boolean;
}) => {
  return workstories.filter(story => {
    if (filters.search && !story.title.toLowerCase().includes(filters.search.toLowerCase()) && 
        !story.summary.toLowerCase().includes(filters.search.toLowerCase())) {
      return false;
    }
    if (filters.domain && !story.domains.includes(filters.domain)) {
      return false;
    }
    if (filters.industry && !story.industries.includes(filters.industry)) {
      return false;
    }
    if (filters.featured && !story.featured) {
      return false;
    }
    return true;
  });
};